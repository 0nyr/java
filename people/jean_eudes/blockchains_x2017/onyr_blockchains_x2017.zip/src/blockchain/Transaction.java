package blockchain;

import console.ANSIColorCode;
import console.Console;

public class Transaction {

    private final Client c1;
    private final Client c2;
    private final int montant;

    public Transaction(Client c1, Client c2, int montant) {
        this.c1 = c1;
        this.c2 = c2;
        this.montant = montant;
        executer();
    }

    public void executer() {
        c1.ajouterMontant(-montant);
        c2.ajouterMontant(montant);
    }

    public String toString() {
        return String.format("[%s, %s, %d]", 
            c1.toString(), c2.toString(), montant
        );
    }

    public long hash() {
        long hash = 7;
        hash = 31*hash + c1.hash();
        hash = 31*hash + c2.hash();
        hash = 31*hash + (long)(montant);

        Console.printlnFgColor("Transaction.hash() : " + hash, ANSIColorCode.DEBUG_C);

        return hash;
    }
    
}
