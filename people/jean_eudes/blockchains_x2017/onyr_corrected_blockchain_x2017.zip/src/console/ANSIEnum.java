package console;

public interface ANSIEnum {
    
}
