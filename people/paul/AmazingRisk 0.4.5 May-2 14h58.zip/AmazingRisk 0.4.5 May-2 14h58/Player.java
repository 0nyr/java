import java.util.LinkedList;

public class Player extends Entity {


    public Player (String name, String attributedColour) {
        super(name, "Player", attributedColour);
    }


}
