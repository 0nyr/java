import java.util.StringTokenizer;

public class TitleOf {
	
	protected static String version = "Amazing Risk 0.4.5" ;
	protected static String AmazingMenu=version+" - Main Menu" ;
	protected static String Initializer=version+" - Prepare the game (local game)" ;
	protected static String MainWindow=version+" - Current game" ;
	protected static String StatsFrame=version+" - Statistics" ;
	protected static String RankingFrame=version+" - Ranking" ;
	protected static String LackOfData=version+" - Not enough datas yet" ;
	protected static String OnlineFrame=version+" - Play online" ;
	protected static String RollingFrame=version+" - Battle" ;
	protected static String ServerCreationFrame=version+" - Online Game Creation Menu" ;
	protected static String PlayerServerMenu =version+" - Player Server Menu" ;
	protected static String ServerJoinFrame = version+ " - Online Game Join Menu";
}
